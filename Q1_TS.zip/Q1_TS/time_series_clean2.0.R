# Carnival Case Study - Time Series Analysis
# Data retrived from Department for Transport Statistics, UK

library(zoo)
library(fBasics)
library(TSA)
library(forecast)
library(fUnitRoots)
library(tseries)
library(astsa)

###Observations#################################################################

# Evaluate general time-series plot from the data
# Evaluate the decomposition plot
# Evaluate the boxplot for seasonality

#*******************************************************************************

#basic statistics and time-seires plot

setwd("C:/Users/hwhua/Desktop/RM")

passenger.ts <- ts(read.table(file = "monthly_passenger_adj.txt", header = FALSE),
                   frequency = 12,
                   start = c(1999,1))

plot(passenger.ts,
     ylab="Number of Passengers", 
     xlab="Year", 
     type="l", 
     main = "Number of passengers departure from UK from Jan 1999 to Dec 2018")


# Decomposed Plot
passenger.ts.decomp <- decompose(passenger.ts)


plot(passenger.ts.decomp)

# Box-plot

boxplot(passenger.ts ~ cycle(passenger.ts), 
        main = 'Boxplot of monthly passenger seasonality',
        xlab = 'month') 

# plot across months, a sense on seasonal effect


###Evaluations##################################################################

# Evaluate the acf and pacf for correlations
# Evaluate the adf and KPSS test for stationarity
# Transformation for removing trends 
# Evaluate of data after removing trends

#*******************************************************************************

# ACF and PACF on time series data


acf(passenger.ts,
    main = "ACF of passengers' time-series (residual)")

pacf(passenger.ts, 
     main = "PACF of passengers' time-series (residual)")

# The ACF plot suggest a non-stationary time series and potentially a seasonality (a spike every 10-12). 
# The pacf indicates that the time series could seasonality of (0,0,1) given the decay


# ADF test

adf.test(passenger.ts)

# KPSS test

kpss.test(passenger.ts,
          null = "Level")						# KPSS test

# We have enough evidence to reject the null hypothesis, the time series is not stationary,
# We conclude that there are some trends in our time series data

# We have enough evidence from KPSS to reject the null hypothesis and conclude that 
# the time series is not stationary


###Identifications##############################################################

#*******************************************************************************

# identifying the models to be estimated

# auto.arima on time series data

auto.arima(passenger.ts)

#*******************************************************************************

###Estimations##################################################################

fit1 <- Arima(passenger.ts, order=c(0,0,4),seasonal = c(0,1,1), method = 'ML')
fit2 <- Arima(passenger.ts, order=c(0,0,3),seasonal = c(0,1,1), method = 'ML')
fit3 <- Arima(passenger.ts, order=c(0,0,3),seasonal = c(1,1,1), method = 'ML')
fit4 <- Arima(passenger.ts, order=c(1,0,3),seasonal = c(1,1,0), method = 'ML')
fit5 <- Arima(passenger.ts, order=c(0,0,4),seasonal = c(1,1,0), method = 'ML')

fit6 <- Arima(passenger.ts, order=c(1,0,3),seasonal = c(0,1,1), method = 'ML')


fit.AIC <- c(fit1$aic,fit2$aic,fit3$aic,fit4$aic,fit5$aic)
fit.AIC

#*******************************************************************************
###Diagnostic Checking##########################################################

checkresiduals(fit4)



hist(residuals(fit4),
     xlab = "Standardised residuals",
     main = "Histogram for ARIMA(1,0,3)(1,1,0)",
     n=50)

qqnorm(residuals(fit4),
       main = "Q-Q plot for ARIMA(1,0,3)(1,1,0)")

qqline(residuals(fit4))

acf(residuals(fit4),
    main = "ACF for ARIMA(1,0,3)(1,1,0) standardized residuals")

shapiro.test(residuals(fit4))

Box.test(residuals(fit4),
         lag = 12,
         type = "Ljung-Box",
         fitdf = 4)


###Predictions##################################################################
predict(fit4,n.ahead = 24)

futurVal <- forecast(fit4,h=24, level=c(99.5))
plot(futurVal)


#*******************************************************************************************



plot(passenger.ts, 
     col = "red",
     ylab = "Number of cruise passengers in UK ",
     xlab = "Year",
     main = "Original time series vs. Fitted time series")

fitted <- passenger.ts - fit4$residuals
lines(fitted, col="blue")

legend("topleft",
       c("Original","Fitted"),
       col = c("red","blue"),
       lty = 1:2,
       bty = "n")
